function RandomBattleCalculateSeeds(number){var result=[];var seed;for(var i=0;i<number;i++){seed="";Object.keys(RandomBattleSeedsBlueprint).forEach(function(facet){var mask=Math.pow(10,RandomBattleSeedsBlueprint[facet]["size"]);var tmpString=String(mask+RandomInstance.nextInt(mask));seed+=tmpString.slice(1);});console.log(seed.slice(0));if(i!==0&&i%7===0){console.log("\n");}
result.push(seed.slice(0));}
return result;}
function RandomBattleCalculateStartEnd(blueprint){var index=0;Object.keys(blueprint).forEach(function(key){blueprint[key]["start"]=index;index+=blueprint[key]["size"];blueprint[key]["end"]=index;});return blueprint;}
function RandomBattleWeightNormalization(pool){var weightSum=pool.reduce(function(sum,weight){return sum+weight.weight;},0);return pool.map(function(item){return item.weight/weightSum;});}
function RandomBattleGenderSelection(seed){return seed%2===1?GENDER.MALE:GENDER.FEMALE;}
function RandomBattleAppearanceSelection(seed){return WarriorAppearences.Zombie;}
function RandomBattleItemSelection(seed,pool,shadowsPool,supersPool){var itemChances=RandomBattleWeightNormalization(pool.items);var accumulator=0;for(var i=0;i<pool.items.length;i++){if(accumulator+itemChances[i]>seed){shadowsPool.push(pool.abilities);supersPool.push(pool.items[i].supers);return pool.items[i].item;}
else{accumulator+=itemChances[i];}}}
function RandomBattleTagsSelection(seed,pool){var tagChances=RandomBattleWeightNormalization(pool);var accumulator=0;for(var i=0;i<pool.length;i++){if(accumulator+tagChances[i]>seed){return[{RuleBlocks:[rule(RoundRules.GiveTag,RRA.Tag,pool[i].item,RRA.ApplyTo,PLAYER)]}];}
else{accumulator+=tagChances[i];}}
return[];}
function RandomBattleSuperSelection(seed,pool){var tagChances=RandomBattleWeightNormalization(pool);var accumulator=0;for(var i=0;i<pool.length;i++){if(accumulator+tagChances[i]>seed){return[{RuleBlocks:[rule(RoundRules.GiveTag,RRA.Tag,pool[i].baseTag,RRA.ApplyTo,PLAYER)]},{RuleBlocks:[rule(RoundRules.GiveTag,RRA.Tag,pool[i].superTag,RRA.ApplyTo,PLAYER)]},];}
else{accumulator+=tagChances[i];}}
return[];}
function RandomBattleMajorRulesSelection(seed,pool,minorsPool,perksPool){var rulesChances=RandomBattleWeightNormalization(pool);var accumulator=0;for(var i=0;i<pool.length;i++){if(accumulator+rulesChances[i]>seed){minorsPool.push(pool[i].minors);perksPool.push(pool[i].perks);return[{RuleBlocks:[pool[i].major]}];}
else{accumulator+=rulesChances[i];}}
return[];}
function RandomBattleMinorRulesSelection(seed,pool){var rules=deepCopy(pool);var rulesChances=RandomBattleWeightNormalization(rules);var threshold;if(seed.threshold<0.15){threshold=0;}
else if(seed.threshold<0.405){threshold=1;}
else if(seed.threshold<0.67275){threshold=2;}
else if(seed.threshold<0.8691){threshold=3;}
else if(seed.threshold<0.0967275){threshold=4;}
else if(seed.threshold<0.9967275){threshold=5;}
else if(seed.threshold<1){threshold=6;}
var result=[];var accumulator=0;var i=0;while(rules.length>0&&i<=threshold){accumulator=0;var minorToRemove=-1;for(var j=0;j<rules.length;j++){var minor=rules[j];if(accumulator+rulesChances[j]>seed[i]){result.push({RuleBlocks:[minor.rule]});minorToRemove=j;break;}
else{accumulator+=rulesChances[j];minorToRemove=-1;}}
if(minorToRemove!==-1){rules.splice(minorToRemove,1);rulesChances=RandomBattleWeightNormalization(rules);}
i++;}
return result;}
function RandomBattlePerksSelection(seed,pool){return[];}