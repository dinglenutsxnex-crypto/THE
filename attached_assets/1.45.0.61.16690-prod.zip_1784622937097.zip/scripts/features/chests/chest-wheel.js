function initChestCounters(){var result={};for(var type in InitialCounters){if(InitialCounters.hasOwnProperty(type)){var typeID=ChestType[type];result[typeID]=Math.floor(InitialCounters[type].getValue(RandomInstance));}}
result[ChestType.TUTORIAL_CHEST]=1;result[ChestType.FIRST_RARE_CHEST]=4;result[ChestType.RARE_CHEST]+=4;return result;}
function updateChestCounters(currentCounters,danID,prevDanID){var counters={};var chestDrop=null;var dan=getDan(danID);for(var type in currentCounters){var typeName=ChestType[type];var currCounter=currentCounters[type];if(currCounter>0){if(currCounter===1){if(!chestDrop||(Chests[typeName].Priority>Chests[chestDrop].Priority)){chestDrop=typeName;counters[type]=currCounter;}}
else{counters[type]=currCounter-1;}}}
var chestDropID;if(chestDrop){chestDropID=ChestType[chestDrop];if(chestDrop in dan.ChestFrequency){counters[chestDropID]=Math.floor(dan.ChestFrequency[chestDrop].getValue(RandomInstance));if(!counters[chestDropID]){throw("updateChestCounters: bad chest frequency for type "+chestDrop+" dan "+dan.ID);}}
else{counters[chestDropID]=0;}}
else{chestDropID=Chests.COMMON_CHEST.ID;}
return{Chest:chestDropID,Counters:counters};}
function chestSetNextChestRarity(currentCounters,rarity){var counters={};for(var type in currentCounters){var currCounter=currentCounters[type];if(currCounter==1){currCounter=2;}
counters[type]=currCounter;}
counters[rarity]=1;return counters;}
function danChangeChestCounters(currentCounters,danID,prevDanID){var counters={};var dan=getDan(danID);var prevDan=getDan(prevDanID);for(var type in currentCounters){var typeName=ChestType[type];var currCounter=currentCounters[type];if((typeName in dan.ChestFrequency)&&(typeName in prevDan.ChestFrequency)){currCounter+=dan.ChestFrequency[typeName].getCenter()-prevDan.ChestFrequency[typeName].getCenter();currCounter=Math.max(currCounter,1);}
counters[type]=currCounter;}
return counters;}
function resetChestCounters(counters,danID){var result={};var dan=getDan(danID);for(var type in counters){var typeID=Number(type);var currentValue=Math.floor(counters[type]);if(currentValue>0){if(typeID==ChestType.EPIC_CHEST){result[ChestType.EPIC_CHEST_NEW]=Math.max(1,Math.floor(dan.ChestFrequency.EPIC_CHEST_NEW.getValue(RandomInstance)*Math.min(1,currentValue/100)));}
else if(typeID==ChestType.LEGENDARY_CHEST){result[ChestType.LEGENDARY_CHEST_NEW]=Math.max(1,Math.floor(dan.ChestFrequency.LEGENDARY_CHEST_NEW.getValue(RandomInstance)*Math.min(1,currentValue/300)));}
else{result[type]=currentValue;}}}
for(var type in ChestType){if(Number(type)){var typeName=ChestType[type];if(typeName in dan.ChestFrequency){if(!result[type]||result[type]<=0){result[type]=Math.max(1,Math.floor(dan.ChestFrequency[typeName].getValue(RandomInstance))-10);}
else if(result[type]>dan.ChestFrequency[typeName].getMax()+4){result[type]=Math.floor(dan.ChestFrequency[typeName].getValue(RandomInstance));}}}}
return result;}